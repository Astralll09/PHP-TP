<?php

define("ROOT", $_SERVER["DOCUMENT_ROOT"]);